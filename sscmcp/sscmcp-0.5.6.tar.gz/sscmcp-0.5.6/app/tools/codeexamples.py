#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
NASA SSC MCP Server tool to produce client code examples of calling the
SSC web services for information.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from typing import Annotated

from pydantic import Field

from fastmcp.exceptions import ToolError

from app.config import mcp, ssc


@mcp.tool(
    name="get_client_library_example",
    description="Gets example code to access SSC observatory "
        "(satellite) location information using the sscws library "
        "for the given observatory and programming language."
)
def get_client_library_example_code(
    observatory: Annotated[
        str,
        Field(description="Observatory whose location information "
                  "is being requested by the example code. The values "
                  "must be from the set of id values returned by "
                  "get_observatories()")
        ],
    language: Annotated[
        str,
        Field(description="Programming languge of example code. "
                  "Must be Python or IDL",
              pattern=r'(?i)Python|IDL')
        ]
) -> str:
    """
    Gets client library example code for the given observatory and
    programming language.

    Parameters
    ----------
    observatory
        The observatory to use in the example code.  It must be an Id
        returned by get_observatories.
    language
        The programming language of the example code.  It must be either
        Python or IDL.

    Returns
    -------
    str
        Requested client library example code.
    """

    client_library_example = \
        ssc.get_client_library_example(observatory.lower(), language)

    if client_library_example is not None:
        return client_library_example

    raise ToolError('Invalid observatory value')
