#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Example prompt to request observatory/satellite information from the NASA 
SSC MCP Server.

Copyright &copy; 2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from typing import Annotated, List

from pydantic import Field

from fastmcp.prompts import Message

from app.config import mcp


@mcp.prompt
def get_observatories(
) -> List[Message]:
    """ 
    A prompt to get the observatories/satellites available at the NASA's SSC.
    """
    return [
        Message("What observatories/satellites are available at NASA's SSC?")
    ]


@mcp.prompt
def get_observatory_time_range(
    observatory: Annotated[
        str,
        Field(description="Observatory whose time range of available "
                  "location information at NASA's Satellite Situation "
                  "Center (SSC) is being requested. The values "
                  "must be from the set of id values returned by "
                  "get_observatories()")
        ],
) -> List[Message]:
    """ 
    A prompt to get the available time range of location information a
     observatories/satellites at the NASA's SSC.
    """
    return [
        Message("Over what time range does NASA's SSC have location "
                f"information for {observatory}?")
    ]
