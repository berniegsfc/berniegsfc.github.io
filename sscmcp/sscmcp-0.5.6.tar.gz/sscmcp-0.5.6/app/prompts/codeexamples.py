#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Example code prompts for NASA SSC MCP Server.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from typing import Annotated, List

from pydantic import Field

from fastmcp.prompts import Message

from app.config import mcp


@mcp.prompt
def generate_example_code(
    observatory: Annotated[
        str,
        Field(description="Observatory whose location information "
                  "is being requested by the example code. The values "
                  "must be from the set of id values returned by "
                  "get_observatories()")
        ],
    language: Annotated[
        str,
        Field(description="Programming languge of example code. "
                  "Must be Python or IDL",
              pattern=r'(?i)Python|IDL')
        ]
) -> List[Message]:
    """ 
    A prompt to get example Python/IDL code to get location information 
    from SSC.
    """

    return [
        Message(f"Write {language} example code to get location "
                f"information for {observatory} from SSC."),
        Message("I'll help you write that code.", role="assistant"),
    ]
