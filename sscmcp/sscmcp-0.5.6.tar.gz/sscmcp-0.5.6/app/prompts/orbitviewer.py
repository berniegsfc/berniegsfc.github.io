#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Example code prompts for NASA SSC MCP Server.

Copyright &copy; 2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from datetime import datetime
from typing import Annotated, List

from pydantic import Field

from fastmcp.prompts import Message

from app.config import mcp


@mcp.prompt
def show_4d_orbit_view(
    observatories: Annotated[
        # List[str], didn't work well with old fast-agent-mcp. try with newer agents
        str,
        Field(description="Observatories whose orbit is to be displayed. "
                  "The values must be from the set of id values returned "
                  "by get_observatories()",
              min_length=1)
    ],
    start: Annotated[datetime, "Start of the time interval to display"],
    end: Annotated[datetime, "End of the time interval to display"],
) -> List[Message]:
    """ 
    A prompt to display an interactive 4D orbit viewer application showing the
    given spacecraft orbits during the given time range.
    """
    return [
        Message(f"Display an interactive 4D orbit viewer showing the orbit "
                f"of {observatories} during the time from {start} to {end}.")
    ]
