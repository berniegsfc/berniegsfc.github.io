#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Prompts to get location related information from NASA' Satelite
Situation Center (SSC).

Copyright &copy; 2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from datetime import datetime
from typing import Annotated, List

from pydantic import confloat, Field

from fastmcp.prompts import Message

from app.config import mcp


@mcp.prompt
def get_radial_traced_conjunctions(
    observatory: Annotated[
        str,
        Field(description="Observatory involved in conjunction")
        ],
    start: Annotated[
        datetime, "Start of the time interval to search for a conjunction"],
    end: Annotated[
        datetime, "End of the time interval to search of a conjunction"],
    gs_latitude: Annotated[
        confloat(gt=-90.0, lt=90.0),
        Field(description="Ground station GEO Latitude")
    ],
    gs_longitude: Annotated[
        confloat(gt=-180.0, lt=360.0),
        Field(description="Ground station GEO Longitude")
    ],
    coord_system: Annotated[
        str,
        Field(description="Coordinate system to use for representing "
                  "the observatory's location information",
              pattern=r'(?i)GEO|GM|GSE|GSM|GEI_TOD|GEI_J_2000',
              default='GEO')
    ],
    ground_station_name: Annotated[
        str,
        Field(description="Ground station name",
              pattern=r'^[A-Z]{1,4}$',
              default='GS1')
    ]
) -> List[Message]:
    """ 
    A prompt to get the radial traced conjunctions between the specified
    observatory/satellite and the specified ground station during a
    specified time range.
    """
    return [
        Message( "Get the the radial traced conjunctions "
                f"(time range and satellite location) between {observatory} "
                f"and a ground station nameed {ground_station_name} at GEO "
                f"{gs_latitude}, {gs_longitude} during the time interval of "
                f"{start} to {end}.")
    ]
