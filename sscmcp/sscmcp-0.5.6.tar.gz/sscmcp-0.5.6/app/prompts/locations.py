#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Prompts to get location related information from NASA' Satelite
Situation Center (SSC).

Copyright &copy; 2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from datetime import datetime
from typing import Annotated, List

from pydantic import Field

from fastmcp.prompts import Message

from app.config import mcp


@mcp.prompt
def get_location_info(
    observatory: Annotated[
        str,
        Field(description="Observatory whose location information "
                  "is being requested")
        ],
    start: Annotated[
        datetime, "Start of the time interval of information "
                               "being requested"],
    end: Annotated[
        datetime, "End of the time interval of information "
                             "being requested"],
    coord_system: Annotated[
        str,
        Field(description="Coordinate system to use for representing "
                  "location information",
              pattern=r'(?i)GEO|GM|GSE|GSM|GEI_TOD|GEI_J_2000',
              default='GSE')
    ]
) -> List[Message]:
    """ 
    A prompt to get location information in the specified coordinate 
    system from SSC for the specified observatory/satellite and time range.
    """
    return [
        Message(f"Get the location of {observatory} in {coord_system} "
                f"for time from {start} to {end}.")
    ]


@mcp.prompt
def get_location_bfield_footpoints(
    observatory: Annotated[
        str,
        Field(description="Observatory whose location information "
                  "is being requested")
        ],
    start: Annotated[
        datetime, "Start of the time interval of information "
                               "being requested"],
    end: Annotated[
        datetime, "End of the time interval of information "
                             "being requested"],
    coord_system: Annotated[
        str,
        Field(description="Coordinate system to use for representing "
                  "location information",
              pattern=r'(?i)GEO|GM|GSE|GSM|GEI_TOD|GEI_J_2000',
              default='GSE')
    ]
) -> List[Message]:
    """ 
    A prompt to get location information from SSC in the specified
    coordinate system for the specified observatory/satellite and time
    range with magnetic field line traced footpoints.
    """
    return [
        Message(f"Get the location of {observatory} in {coord_system} "
                f"for time from {start} to {end}.  Include the north and "
                 "south magnetic field line traced footpoints in GEO "
                 "latitude and longitude coordinates. Display the "
                 "information in a tabular form for all timestamps.")
    ]
