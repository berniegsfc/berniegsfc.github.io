#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Module to implement a Model Context Protocol (MCP) server for NASA's
Satellite Situation Center (SSC).

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

# Import config to initialize mcp server
from app.config import mcp

# pylint: disable=unused-import
# Dispite what pylint thinks, these imports are needed to register the
# tools and prompts with the ssc mcp app.

import app.prompts.examples
import app.resources.observatories
import app.resources.groundstations
import app.tools.conjunctions
import app.tools.coordinates
import app.tools.elicitation
import app.tools.examples
import app.tools.groundstations
import app.tools.info
import app.tools.locations
import app.tools.observatories
import app.tools.orbitviewer

# The following is merely a test for agents.  If they eventually support
# prefab UIs, then maybe a prefab UI for SSC can be implemented.
#import app.tools.prefabapp

# pylint: enable=unused-import

# Create the FastMCP application
app = mcp.http_app(transport="streamable-http", path="/mcp")
""" SSC MCP application."""
