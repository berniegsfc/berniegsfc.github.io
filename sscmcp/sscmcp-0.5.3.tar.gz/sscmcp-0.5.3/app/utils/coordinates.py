#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Coordinate system utilities for NASA SSC MCP Server.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from typing import List

from sscws.coordinates import (
    CoordinateComponent,
    CoordinateSystem
)
from sscws.outputoptions import CoordinateOptions


def create_coordinate_options(
    coordinate_systems: List[CoordinateSystem]
) -> List[CoordinateOptions]:
    """
    Create coordinate options for all components.

    Parameters
    ----------
    coordinate_systems
        List of coordinate systems.

    Returns
    -------
    List[CoordinateOptions]
        CoordinateOptions corresponding to the given List of
        CoordinateSystems.
    """
    coord_options = []
    for c_s in coordinate_systems:
        coordinate_system = \
            CoordinateSystem.from_identifier(c_s.upper())
        coord_options.append(
            CoordinateOptions(coordinate_system=coordinate_system,
                              component=CoordinateComponent.X))
        coord_options.append(
            CoordinateOptions(coordinate_system=coordinate_system,
                              component=CoordinateComponent.Y))
        coord_options.append(
            CoordinateOptions(coordinate_system=coordinate_system,
                              component=CoordinateComponent.Z))
        # others ???
    return coord_options
