#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Error handling utilities for NASA SSC MCP Server.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from typing import Dict

from fastmcp.exceptions import ToolError

from app.config import logger


def raise_toolerror_from_ssc(
    ssc_result: Dict
) -> None:
    """
    Raise a ToolError corresponding to the error reported in ssc_result.

    Parameters
    ----------
    ssc_result
        An SSC ssc_result to raise a ToolError for.
    """
    if 'ErrorMessage' in ssc_result:
        logger.warning('%s: %s', ssc_result['ErrorMessage'],
                        ssc_result['ErrorDescription'])
        raise ToolError(f"{ssc_result['ErrorMessage']}: "
                        f"{ssc_result['ErrorDescription']}")
    logger.warning(ssc_result['ErrorText'])
    raise ToolError(ssc_result['ErrorText'])
