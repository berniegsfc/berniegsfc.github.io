#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying warnrmation:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Module to provide conversion between the original sscws objects and
versions required by the SSC Model Context Protocol (MCP) server and 
AI client agents.
<br>

Copyright &copy; 2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from typing import Dict


def convert_numpy_arrays(
    ssc_result: Dict
) -> Dict:
    """
    Converts an ssc result containing numpy arrays to one containing
    native Python Lists.  The conversion is for transfer across
    MCP's JSON-RPC interface.

    Parameters
    ----------
    result
        A result from SSC containing numpy arrays that are to be 
        converted to native Python Lists.

    Returns
    -------
    Dict
        The equivalent of the given numpy_result with all numpy arrays
        converted to Python Lists.
    """


    if 'Conjunction' in ssc_result:
        return convert_conjunction_numpy_arrays(ssc_result)
    if 'Data' in ssc_result:
        return convert_data_numpy_arrays(ssc_result)
    return ssc_result


# pylint: disable=too-many-branches
def convert_data_numpy_arrays(
    result: Dict
) -> Dict:
    """
    Converts an ssc data result containing numpy arrays to one containing
    native Python Lists.  The conversion is for transfer across
    MCP's JSON-RPC interface.

    Parameters
    ----------
    result
        A result from SSC containing numpy arrays that are to be 
        converted to native Python Lists.

    Returns
    -------
    Dict
        The equivalent of the given numpy_result with all numpy arrays
        converted to Python Lists.
    """
    result['Data'] = result['Data'].tolist()
    for data in result['Data']:
        data['Coordinates'] = data['Coordinates'].tolist()
        for coord in data['Coordinates']:
            for name in ['X', 'Y', 'Z', 'Latitude', 'Longitude', 'LocalTime']:
                coord[name] = coord[name].tolist()
        data['Time'] = data['Time'].tolist()
        if 'BTraceData' in data:
            b_trace_data_list = data['BTraceData'].tolist()
            data['BTraceData'] = b_trace_data_list
            for b_trace_data in b_trace_data_list:
                for name in ['Latitude', 'Longitude', 'ArcLength']:
                    b_trace_data[name] = b_trace_data[name].tolist()
        if 'RadialLength' in data:
            data['RadialLength'] = data['RadialLength'].tolist()
        if 'MagneticStrength' in data:
            data['MagneticStrength'] = data['MagneticStrength'].tolist()
        if 'NeutralSheetDistance' in data:
            data['NeutralSheetDistance'] = data['NeutralSheetDistance'].tolist()
        if 'BowShockDistance' in data:
            data['BowShockDistance'] = data['BowShockDistance'].tolist()
        if 'MagnetoPauseDistance' in data:
            data['MagnetoPauseDistance'] = data['MagnetoPauseDistance'].tolist()
        if 'DipoleLValue' in data:
            data['DipoleLValue'] = data['DipoleLValue'].tolist()
        if 'DipoleInvariantLatitude' in data:
            data['DipoleInvariantLatitude'] = data['DipoleInvariantLatitude'].tolist()
        if 'SpacecraftRegion' in data:
            data['SpacecraftRegion'] = data['SpacecraftRegion'].tolist()
        if 'RadialTracedFootpointRegions' in data:
            data['RadialTracedFootpointRegions'] = data['RadialTracedFootpointRegions'].tolist()
        if 'BGseX' in data:
            data['BGseX'] = data['BGseX'].tolist()
        if 'BGseY' in data:
            data['BGseY'] = data['BGseY'].tolist()
        if 'BGseZ' in data:
            data['BGseZ'] = data['BGseZ'].tolist()
        if 'NorthBTracedFootpointRegions' in data:
            data['NorthBTracedFootpointRegions'] = data['NorthBTracedFootpointRegions'].tolist()
        if 'SouthBTracedFootpointRegions' in data:
            data['SouthBTracedFootpointRegions'] = data['SouthBTracedFootpointRegions'].tolist()

    return result
    # pylint: enable=too-many-branches


def convert_conjunction_numpy_arrays(
    result: Dict
) -> Dict:
    """
    Converts an ssc conjunction result containing numpy arrays to one
    containing native Python Lists.  The conversion is for transfer across
    MCP's JSON-RPC interface.

    Parameters
    ----------
    result
        A conjunction result from SSC containing numpy arrays that are to
        be converted to native Python Lists.

    Returns
    -------
    Dict
        The equivalent of the given numpy_result with all numpy arrays
        converted to Python Lists.
    """
    conjunctions = result['Conjunction'].tolist()
    for conjunction in conjunctions:
        sat_descriptions = conjunction['SatelliteDescription'].tolist()
        conjunction['SatelliteDescription'] = sat_descriptions
        for sat_description in sat_descriptions:
            sat_description['Description'] = \
                sat_description['Description'].tolist()

    result['Conjunction'] = conjunctions
    return result
