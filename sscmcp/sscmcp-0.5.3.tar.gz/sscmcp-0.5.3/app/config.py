#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Configuration module for NASA SSC MCP Server.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

import logging

from fastmcp import FastMCP

from sscws.sscws import SscWs

from mcp.types import Icon

from app import __version__



# Initialize SSC Web Services client
ssc = SscWs(user_agent='MCP/' + __version__)
""" The SSC server."""

# Initialize FastMCP server
mcp = FastMCP(
    name="NASA SSC MCP Server",
    mask_error_details=False,  # may want True in operational environment
    on_duplicate="warn",
    instructions="""
        This Model Context Protocol (MCP) server provides access to NASA's Satellite Situation Center (SSC).
        Call get_observatories() to get information on the available satellites (observatories).
        Call get_ground_stations() to get information on the available ground stations.
        Call get_locations() to get location information on the specified satellite (observatory).
        Call get_location_info() to get location information (including values related to Earth's magnetic field) on the specified satellite (observatory).
        Call get_conjunctions() to get radial and magnetic field line traced conjunction between satellites and ground stations.
    """,
    version=__version__,
    website_url="https://sscweb.gsfc.nasa.gov/",
    icons=[
        Icon(
            src="https://sscweb.gsfc.nasa.gov/logos/nasa-logo.svg",
            mimeType="image/svg+xml"
        )
    ]
)
""" SSC MCP Server."""

logger = logging.getLogger(__name__)
""" SSC MCP Logger."""
