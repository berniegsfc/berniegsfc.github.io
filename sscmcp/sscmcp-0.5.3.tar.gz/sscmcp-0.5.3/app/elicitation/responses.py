#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Module containing user elicitation responses.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from enum import Enum

from pydantic import BaseModel, Field

from sscws.bfieldmodels import (
    InternalBFieldModel,
    ExternalBFieldModelName,
    Tsyganenko87Kp,
    Tsyganenko89cKp
)
from sscws.tracing import TraceCoordinateSystem


class Tsyganenko87KpResponse(BaseModel):
    """
    Class represents a Tsyganenko87 key parameter elicitation
    response.

    Note: This class may become unnecessary if fastmcp elicitation
    were to support default values for enum elicitations.
    """
    key_parameters: Tsyganenko87Kp = \
        Field(default=Tsyganenko87Kp.KP_3_3_3,
              description="Tsyganenko87 key parameters.")
    """ Model key parameter values."""


class Tsyganenko89cKpResponse(BaseModel):
    """
    Class represents a Tsyganenko89c key parameter elicitation
    response.

    Note: This class may become unnecessary if fastmcp elicitation
    were to support default values for enum elicitations.
    """
    key_parameters: Tsyganenko89cKp = \
        Field(default=Tsyganenko89cKp.KP_3_3_3,
              description="Tsyganenko89c key parameters.")
    """ Model key parameter values."""


class Tsyganenko96Response(BaseModel):
    """
    Class represents a Tsyganenko96 B field model parameter elicitation
    response.

    Fields
    ------
    solar_wind_pressure
    dst_index
    by_imf
    bz_imf
    """
    solar_wind_pressure: float = \
        Field(default = 2.1,
              description="Solar Wind Pressure (0 - 30nP)")
    dst_index: int = \
        Field(default = -20,
              description="DST (-400 - 200nT)")
    by_imf: float = \
        Field(default = 0.0,
              description="BY IMF (-100 - 100nT)")
    bz_imf: float = \
        Field(default = 0.0,
              description="BZ IMF (-100 - 100nT)")


class BFieldModelResponse(BaseModel):
    """
    Class represents a BFieldModel elicitation response.

    Fields
    ------
    internal
        Selected internal B field model.
    external
        Selected external B field model.
    trace_stop_altitude
        Stop altitude for downward tracing of field lines.
    """
    internal: InternalBFieldModel =\
        Field(default=InternalBFieldModel.IGRF,
              description="Internal magnetic field model")
    external: ExternalBFieldModelName =\
        Field(default=ExternalBFieldModelName.TSYGANENKO89C,
              description="External magnetic field model")
    trace_stop_altitude: int =\
        Field(default=100, ge=0,
              description="Stop altitude (km) for downward tracing field lines")


class ConjunctionAreaResponse(Enum):
    """
    Class represents a ConjunctionArea elicitation response.

    """
    BOX = 'Box'
    """ Rectangular conjunction area."""
    CIRCLE = 'Circle'
    """ Circular conjunction area."""


class BoxConjunctionAreaResponse(BaseModel):
    """
    Class represents a BoxConjunctionArea elicitation response.

    """
    coordinate_system: TraceCoordinateSystem = \
        Field(default=TraceCoordinateSystem.GEO,
              description="Trace coordinate system.")
    delta_latitude: float = \
        Field(default=3.0,
              description="Delta latitude (degrees).")
    delta_longitude: float = \
        Field(default=10.0,
              description="Delta longitude (degrees).")


class DistanceConjunctionAreaResponse(BaseModel):
    """
    Class represents a DistanceConjunctionArea elicitation response.

    """
    radius: float = \
        Field(default=400.0,
              description="Radius (kilometers)")
