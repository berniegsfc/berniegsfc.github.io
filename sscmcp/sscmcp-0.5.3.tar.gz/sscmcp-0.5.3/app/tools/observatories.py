#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Observatory tools for NASA SSC MCP Server.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from typing import Annotated, Dict, List, Optional

from pydantic import Field

from app import __version__
from app.config import mcp, ssc, logger
from app.utils.errors import raise_toolerror_from_ssc


@mcp.tool(
    name="get_observatories",
    description="Gets descriptions of the satellites (observatories) "
        "available at NASA's Satellite Situation Center",
    meta={"version": __version__, "author": "Bernie Harris"}
)
async def get_observatories(
    observatories: Annotated[
        Optional[List[str]],
        Field(description="Observatories whose description is being "
                  "requested. The values must be from the set of id "
                  "values returned by get_observatories([]).  When "
                  "this list is empty, all descriptions are returned.",
              min_length=0)
    ]
) -> List[Dict]:
    """
    Gets a description of the available SSC observatories.

    Parameters
    ----------
    observatories
        List of observatories whose descriptions are being requested.
        If none are provide, all will be returned.

    Returns
    -------
    List[Dict]
        List of available observatories.  Each list item mirrors
        the structure of an Observatory as definded in
        <https://sscweb.gsfc.nasa.gov/WebServices/REST/SSC.xsd>.

    Raises
    ------
    ToolError
        Raised when sscws reports an error.
    """
    logger.debug('get_observatories: beginning. len(observatories) = %d',
                 len(observatories))
    result = ssc.get_observatories(observatories)
    if result['HttpStatus'] == 200:
        obs_descriptions = result['Observatory']
        logger.debug('get_observatories: len(obs_descriptions) = %d',
                 len(obs_descriptions))
        return obs_descriptions
    logger.warning('ssc.get_observatories failed')
    raise_toolerror_from_ssc(result)
