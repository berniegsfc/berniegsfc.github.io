#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
User elicitation tools for NASA SSC MCP Server.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from typing import Annotated, List

from fastmcp.dependencies import CurrentContext
from fastmcp.server.context import Context
from fastmcp.server.elicitation import (
    AcceptedElicitation,
    DeclinedElicitation,
    CancelledElicitation,
)

from sscws.bfieldmodels import (
    BFieldModel,
    ExternalBFieldModelName,
    Tsyganenko96BFieldModel,
    Tsyganenko89cBFieldModel,
    Tsyganenko87BFieldModel,
    Tsyganenko87Kp,
    Tsyganenko89cKp
)
from sscws.coordinates import CoordinateSystem
from sscws.conjunctions import (
    BoxConjunctionArea,
    ConjunctionArea,
    DistanceConjunctionArea,
)

from mcp.shared.exceptions import McpError

from app import __version__
from app.config import mcp, logger
from app.elicitation.responses import (
    Tsyganenko87KpResponse,
    Tsyganenko89cKpResponse,
    Tsyganenko96Response,
    BFieldModelResponse,
    ConjunctionAreaResponse,
    BoxConjunctionAreaResponse,
    DistanceConjunctionAreaResponse,
)


@mcp.tool(
    name="get_coordinate_system",
    description="Gets the user's selected coordinate system.",
    meta={"version": __version__, "author": "Bernie Harris"}
)
async def get_coordinate_system(
    ctx: Context = CurrentContext()
) -> List[CoordinateSystem]:
    """
    Get the user's selected coordinate system.

    Parameters
    ----------
    ctx
        MCP Context.

    Returns
    -------
    List[CoordinateSystem]
        User's chosen coordinate system.
    """
    result = await ctx.elicit(
        message="Select a coordinate system.",
        response_type = CoordinateSystem
    )
    match result:
        case AcceptedElicitation(data=coordinate_system):
            return [coordinate_system]
        case DeclinedElicitation():
            return [CoordinateSystem.GSE]
        case CancelledElicitation():
            return [CoordinateSystem.GSE]


@mcp.tool
async def get_tsyganenko87_kp(
    ctx: Context = CurrentContext()
) -> Tsyganenko87Kp:
    """
    Get the user's selection of Tsyganenko87 B field model key parameter
    values.

    Parameters
    ----------
    ctx
        MCP Context.

    Returns
    -------
    Tsyganenko87Kp
        User's selected model key parameter values.
    """
    result = await ctx.elicit(
        message="Select the Tsyganenko87 magnetic field model key parameters.",
        response_type = Tsyganenko87KpResponse
    )
    match result:
        case AcceptedElicitation(data=params):
            return params.key_parameters
        case DeclinedElicitation():
            return Tsyganenko87Kp.KP_3_3_3
        case CancelledElicitation():
            return Tsyganenko87Kp.KP_3_3_3


@mcp.tool
async def get_tsyganenko89c_kp(
    ctx: Context = CurrentContext()
) -> Tsyganenko89cKp:
    """
    Get the user's selection of Tsyganenko89c B field model key parameter
    values.

    Parameters
    ----------
    ctx
        MCP Context.

    Returns
    -------
    Tsyganenko89cKp
        User's selected model key parameter values.
    """
    result = await ctx.elicit(
        message="Select the Tsyganenko89c magnetic field model key parameters.",
        response_type = Tsyganenko89cKpResponse,
#        default_value = Tsyganenko89cKp.KP_3_3_3 not with fastmcp 3.2.0
    )
    match result:
        case AcceptedElicitation(data=params):
            return params.key_parameters
        case DeclinedElicitation():
            return Tsyganenko89cKp.KP_3_3_3
        case CancelledElicitation():
            return Tsyganenko89cKp.KP_3_3_3


@mcp.tool
async def get_tsyganenko96_model(
    ctx: Context = CurrentContext()
) -> Tsyganenko96BFieldModel:
    """
    Get the user's selection of Tsyganenko96 B field model parameter values.

    Parameters
    ----------
    ctx
        MCP Context.

    Returns
    -------
    Tsyganenko96BFieldModel
        Containing user's model parameter values.
    """
    result = await ctx.elicit(
        message="Enter the Tsyganenko96 magnetic field model parameters.",
        response_type = Tsyganenko96Response
    )
    match result:
        case AcceptedElicitation(data=params):
            return Tsyganenko96BFieldModel(
                       solar_wind_pressure=params.solar_wind_pressure,
                       dst_index=params.dst_index,
                       by_imf=params.by_imf,
                       bz_imf=params.bz_imf
                   )
        case DeclinedElicitation():
            return Tsyganenko96BFieldModel()
        case CancelledElicitation():
            return Tsyganenko96BFieldModel()


@mcp.tool
async def get_b_field_model(
    ctx: Context = CurrentContext()
) -> BFieldModel:
    """
    Get the user's selection of internal B field model.

    Parameters
    ----------
    ctx
        MCP Context.

    Returns
    -------
    BFieldModel
        User's chosen magnetic field model.
    """
    try:
        result = await ctx.elicit(
            message="Select a magnetic field model.",
            response_type = BFieldModelResponse
        )
        match result:
            case AcceptedElicitation(data=model):
                match model.external:
                    case ExternalBFieldModelName.TSYGANENKO96:
                        t96_model = await get_tsyganenko96_model(ctx)
                        return BFieldModel(internal=model.internal,
                                           external=t96_model,
                                           trace_stop_altitude=model.trace_stop_altitude)
                    case ExternalBFieldModelName.TSYGANENKO89C:
                        t89c_kp = await get_tsyganenko89c_kp(ctx)
                        return BFieldModel(internal=model.internal,
                                           external=Tsyganenko89cBFieldModel(
                                               key_parameters=t89c_kp),
                                           trace_stop_altitude=model.trace_stop_altitude)
                    case ExternalBFieldModelName.TSYGANENKO87:
                        t87_kp = await get_tsyganenko87_kp(ctx)
                        return BFieldModel(internal=model.internal,
                                           external=Tsyganenko87BFieldModel(
                                               key_parameters=t87_kp),
                                           trace_stop_altitude=model.trace_stop_altitude)
            case DeclinedElicitation():
                return BFieldModel()
            case CancelledElicitation():
                return BFieldModel()
    except McpError as e:
        logger.info('get_b_field_model: get_b_field_model() '
                       'raised %s: %s', type(e).__name__, e)
        return BFieldModel()


@mcp.tool
async def get_box_conjunction_area(
    area: Annotated[str, "Description of conjunction area"],
    ctx: Context = CurrentContext()
) -> BoxConjunctionArea:
    """
    Get the user's selection of conjunction area.

    Parameters
    ----------
    ctx
        MCP Context.
    area
        Description of conjunction area.

    Returns
    -------
    BoxConjunctionArea
        User's chosen conjunction area.
    """
    result = await ctx.elicit(
        message=f'Enter the box conjunction area values for {area}.',
        response_type = BoxConjunctionAreaResponse
    )
    match result:
        case AcceptedElicitation(data=response):
            return BoxConjunctionArea(response.coordinate_system,
                                      response.delta_latitude,
                                      response.delta_longitude)
        case DeclinedElicitation():
            return BoxConjunctionArea()
        case CancelledElicitation():
            return BoxConjunctionArea()

@mcp.tool
async def get_distance_conjunction_area(
    area: Annotated[str, "Description of conjunction area"],
    ctx: Context = CurrentContext()
) -> DistanceConjunctionArea:
    """
    Get the user's selection of conjunction area.

    Parameters
    ----------
    ctx
        MCP Context.
    area
        Description of conjunction area.

    Returns
    -------
    DistanceConjunctionArea
        User's chosen conjunction area.
    """
    result = await ctx.elicit(
        message=f'Enter the circular conjunction area values for {area}.',
        response_type = DistanceConjunctionAreaResponse
    )
    match result:
        case AcceptedElicitation(data=response):
            return DistanceConjunctionArea(response.radius)
        case DeclinedElicitation():
            return DistanceConjunctionArea()
        case CancelledElicitation():
            return DistanceConjunctionArea()


@mcp.tool
async def get_conjunction_area(
    area: Annotated[str, "Description of conjunction area"],
    ctx: Context = CurrentContext()
) -> ConjunctionArea:
    """
    Get the user's selection of conjunction area.

    Parameters
    ----------
    ctx
        MCP Context.
    area
        Description of conjunction area.

    Returns
    -------
    ConjunctionArea
        User's chosen conjunction area.
    """
    try:
        result = await ctx.elicit(
            message=f'Select the type of conjunction area for {area}.',
            response_type = ConjunctionAreaResponse
        )
        match result:
            case AcceptedElicitation(data=conjunction_area):
                match conjunction_area:
                    case ConjunctionAreaResponse.BOX:
                        box_conjunction_area = \
                            await get_box_conjunction_area(area, ctx)
                        return box_conjunction_area
                    case ConjunctionAreaResponse.CIRCLE:
                        circle_conjunction_area = \
                            await get_distance_conjunction_area(area, ctx)
                        return circle_conjunction_area
            case DeclinedElicitation():
                return BoxConjunctionArea()
            case CancelledElicitation():
                return BoxConjunctionArea()
    except McpError as e:
        logger.info('get_conjunction_area: elicitation raised %s: %s',
                    type(e).__name__, e)
        return BoxConjunctionArea()
