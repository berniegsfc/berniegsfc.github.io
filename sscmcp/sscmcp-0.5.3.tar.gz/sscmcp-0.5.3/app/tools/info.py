#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Information about the NASA SSC MCP Server.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

import os
import socket
from typing import Dict
# pip install docker
# import docker

from sscws.sscws import __version__ as sscws_version

from app import __version__
from app.config import mcp


# @mcp.resource('config://mcp-information') does not work as well as mcp.tool
@mcp.tool(
    name="get_mcp_information",
    description="Gets information about this Model Context Protocol "
        "(MCP) server.",
    meta={"version": __version__, "author": "Bernie Harris"}
)
async def get_mcp_information(
) -> Dict:
    """
    Gets information about this Model Context Protocol (MCP) server.

    Returns
    -------
    Dict
        Dictionary containing information about this MCP server.
    """

    # docker_env = docker.from_env()
    # image = docker_env.images.get('sscmcp:latest')
    # build_date = images.labels.get('build_date')
    # The following information is useful for debugging but may need to
    # be trimmed for operational use.
    return {
        'name': mcp.name,
        'version': mcp.version,
        'website_url': mcp.website_url,
        'icons': mcp.icons,
        'host': socket.gethostname(),
        'build_date': os.getenv("BUILD_DATE", "unknown"),
        'sscws_version': sscws_version
    }
