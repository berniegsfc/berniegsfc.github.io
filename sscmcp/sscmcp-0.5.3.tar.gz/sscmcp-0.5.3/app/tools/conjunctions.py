#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Conjunction tools for NASA SSC MCP Server.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

import logging
import xml.etree.ElementTree as ET
from typing import Annotated, Dict, List

from pydantic import Field

from fastmcp.dependencies import CurrentContext, CurrentRequest
from fastmcp.exceptions import ToolError
from fastmcp.server.context import Context
from starlette.requests import Request

from sscws.conjunctions import (
    BoxConjunctionArea,
    ConditionOperator,
    DistanceConjunctionArea,
    GroundStationCondition,
    SatelliteCondition,
)
from sscws.request import QueryRequest
from sscws.timeinterval import TimeInterval
from sscws.tracing import TraceType

from app import __version__
from app.config import mcp, ssc, logger
from app.utils.errors import raise_toolerror_from_ssc
from app.utils.conversion import convert_numpy_arrays
from app.tools.elicitation import get_b_field_model, get_conjunction_area


@mcp.tool(
    name="get_conjunctions",
    description="Gets the times and position of radial and magnetic "
        "field line traced conjuctions between satellites and/or "
        "ground stations.",
    annotations={
        "title": "Get Conjunctions"
    },
    meta={"version": __version__, "author": "Bernie Harris"}
)
async def get_conjunctions(
    time_interval: \
        Annotated[TimeInterval, "Time interval of information "
                                "being requested"],
    satellite_condition: \
        Annotated[SatelliteCondition, "Satellite condition"],
    ground_station_condition: \
        Annotated[GroundStationCondition, "Ground station condition"],
    condition_operator: \
        Annotated[ConditionOperator,
                  Field(default=ConditionOperator.ALL,
                        description="Indicates whether any "
                                  "or all conditions must be true")],
    ctx: Context = CurrentContext(),
    request: Request = CurrentRequest()
) -> List[Dict]:
    """
    Gets the times and position of radial and magnetic field line
    traced conjuctions between satellites and/or ground stations.

    Parameters
    ----------
    time_interval
        Time interval in which to find conjunctions.
    satellite_condition
        Satellite conjunction conditions.
    ground_station_condition
        Ground station conjunction conditions.
    condition_operator
        Indicates whether any or all of the conditions must be meet.
    ctx
        MCP Context.
    request
	HTTP request (when HTTP transport).

    Returns
    -------
    List[Dict]
        List of dictionary items whose structure mirrors Conjunction from
        <https://sscweb.gsfc.nasa.gov/WebServices/REST/SSC.xsd>.

    Raises
    ------
    ToolError
        Raised when sscws reports an error.
    """
    logger.info('%s %s %s %s %s %s %s',
                request.client.host if request.client else 'Unknown-IP',
                request.headers.get('user-agent', 'Unknown-UA'),
                time_interval.start.isoformat(), time_interval.end.isoformat(),
                ','.join(sat.identifier for sat in satellite_condition.satellite),
                ','.join(gs.identifier for gs in ground_station_condition.ground_station),
                condition_operator)

    # the agent is overiding the default and passing ANY so force ALL
    # if the agent can't get this correct, should I elicit a value from user?
    condition_operator = ConditionOperator.ALL

    b_field_model_required = False
    for satellite in satellite_condition.satellite:
        if satellite.b_field_trace_direction is not None:
            b_field_model_required = True
            break

    b_field_model = None
    if b_field_model_required:
        ground_station_condition.trace_type = TraceType.B_FIELD
        b_field_model = await get_b_field_model(ctx)

    for ground_station in ground_station_condition.ground_station:
        conjunction_area = ground_station.conjunction_area
        if (conjunction_area is None or
            not isinstance(conjunction_area, BoxConjunctionArea) or
            not isinstance(conjunction_area, DistanceConjunctionArea)):

            ground_station.conjunction_area = \
                await get_conjunction_area(ground_station.name, ctx)

    conditions = [
        satellite_condition,
        ground_station_condition
    ]
    try:
        query = QueryRequest('MCP conjunction query.', time_interval,
                             condition_operator, conditions,
                             b_field_model)
    except ValueError as e:
        logger.info(e)
        raise ToolError(f'Invalid QueryRequest: {e}') from None

    if logger.getEffectiveLevel() == logging.DEBUG:
        query_xml = query.xml_element()
        ET.indent(query_xml, space='    ')
        logger.debug(ET.tostring(query_xml).decode('utf-8'))

    result = ssc.get_conjunctions(query)
    #SscWs.print_conjunction_result(result)
    if result['HttpStatus'] == 200:
        conjunction_result = convert_numpy_arrays(result)['Conjunction']
        return conjunction_result
    logger.warning('ssc.get_conjunctions failed')
    raise_toolerror_from_ssc(result)
