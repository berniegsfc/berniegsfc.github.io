#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
SSC coordinate system tools.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from typing import Dict, List

from sscws.coordinates import CoordinateSystem

from app import __version__
from app.config import mcp


# @mcp.resource('config://mcp-information') does not work as well as mcp.tool
@mcp.tool(
    name="get_coordinate_systems",
    description="Gets the coordinate systems supported by SSC.",
    meta={"version": __version__, "author": "Bernie Harris"}
)
async def get_supported_coordinate_systems(
) -> List[Dict]:
    """
    Gets the coordinate systems supported by SSC.

    Returns
    -------
    List[Dict]
        Dictionary containing information about this MCP server.
    """

    coord_systems = [
        {
            "identifier": CoordinateSystem.GEO.name,
            "description": "Geographic coordinate system."
        },
        {
            "identifier": CoordinateSystem.GM.name,
            "description": "Geomagnetic coordinate system."
        },
        {
            "identifier": CoordinateSystem.GSE.name,
            "description": "Geocentric Solar Ecliptic coordinate system."
        },
        {
            "identifier": CoordinateSystem.GSM.name,
            "description": "Geocentric Solar Magnetospheric coordinate system."
        },
        {
            "identifier": CoordinateSystem.SM.name,
            "description": "Solar Magnetic coordinate system."
        },
        {
            "identifier": CoordinateSystem.GEI_TOD.name,
            "description": "Geocentric Equatorial Inertial coordinate system."
        },
        {
            "identifier": CoordinateSystem.GEI_J_2000.name,
            "description": ("Geocentric Equatorial Inertial coordinate system "
                           "for epoch J2000.0 (GEI2000).")
        }
    ]
    return coord_systems
