#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Location information tools for NASA SSC MCP Server.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from datetime import datetime
from typing import Annotated, Dict, List

from pydantic import Field

from fastmcp.dependencies import CurrentContext, CurrentRequest
from fastmcp.server.context import Context
from starlette.requests import Request

from sscws.bfieldmodels import BFieldModel
from sscws.outputoptions import OutputOptions
from sscws.request import DataRequest, SatelliteSpecification
from sscws.timeinterval import TimeInterval

from mcp.shared.exceptions import McpError

from app import __version__
from app.config import mcp, ssc, logger
from app.utils.errors import raise_toolerror_from_ssc
from app.utils.coordinates import create_coordinate_options
from app.utils.conversion import convert_numpy_arrays
from app.tools.elicitation import get_coordinate_system, get_b_field_model


@mcp.tool(
    name="get_location_info",
    description="Gets the location and additional quantities (e.g., "
        "distance to bowshock) of the specified satellites "
        "(observatories) during the specified time range in the "
        "specified coordinated system.",
    meta={"version": __version__, "author": "Bernie Harris"}
)
async def get_location_info(
    observatories: Annotated[
        List[str],
        Field(description="Observatories whose location is being "
                  "requested. The values must be from the set of id "
                  "values returned by get_observatories()",
              min_length=1)
    ],
    start: Annotated[datetime, "start of the time interval of information "
                               "being requested"],
    end: Annotated[datetime, "end of the time interval of information "
                             "being requested"],
    output_options: Annotated[
        OutputOptions,
        Field(description="Additional quantities to be included in "
                  "results")
    ],
    ctx: Context = CurrentContext(),
    request: Request = CurrentRequest()
) -> Dict:
    """
    Gets the location of the specified satellites (observatories)
    during the specified time range in the specified coordinated system.

    Parameters
    ----------
    observatories
        List of observatories whose location is being requested. The
        values must be from the set of id values returned by
        get_observatories.
    start
        Start of the time interval of locations being requested.
    end
        End of the time interval of locations being requested.
    coordinate_systems
        List of coordinate systems that the locations are to be
        returned.
    ctx
        MCP Context.
    request
	HTTP request (when HTTP transport).

    Returns
    -------
    Dict
        Dictionary whose structure mirrors SatelliteData from
        <https://sscweb.gsfc.nasa.gov/WebServices/REST/SSC.xsd>.

    Raises
    ------
    ToolError
        Raised when sscws reports an error.
    """
    logger.info('%s %s %s %s %s',
                request.client.host if request.client else 'Unknown-IP',
                request.headers.get('user-agent', 'Unknown-UA'),
                start.isoformat(), end.isoformat(),
                ','.join(observatories))

    sats = []
    for observatory in observatories:
        sats.append(SatelliteSpecification(identifier=observatory.lower(),
                                           resolution_factor=1))

    if output_options.depends_upon_b_field_model():

        logger.debug('get_location_info: '
                     'output_options.depends_upon_b_field_model()')
        b_field_model = await get_b_field_model(ctx)
    else:
        logger.info('get_location_info: setting a default b_field_model')
        b_field_model = BFieldModel()

    #logger.debug(f'get_location_info: b_field_model = {b_field_model}')

    if (output_options is None or
        len(output_options.coordinate_options) == 0):
        try:
            coordinate_systems = await get_coordinate_system(ctx)
        except McpError as e:
            logger.info('get_location_info: get_coordinate_system() '
                           'raised %s: %s', type(e).__name__, e)
            coordinate_systems = ['Gse']

        output_options.coordinate_options = \
            create_coordinate_options(coordinate_systems)

    location_request = \
        DataRequest(description="MCP DataRequest",
                    interval=TimeInterval(start=start, end=end),
                    satellites=sats,
                    output_options=output_options,
                    b_field_model=b_field_model)

    result = ssc.get_locations(location_request)
    if result['HttpStatus'] == 200:
        return convert_numpy_arrays(result)
    logger.warning('ssc.get_locations failed')
    raise_toolerror_from_ssc(result)
