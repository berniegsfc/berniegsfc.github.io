#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the
# following below this NOSA HEADER, with the fields enclosed by
# brackets "[]" replaced with your own identifying information:
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2025-2026 United States Government as represented by
# the National Aeronautics and Space Administration. No copyright is
# claimed in the United States under Title 17, U.S.Code. All Other
# Rights Reserved.
#
#

"""
Obit viewer tool for NASA SSC MCP Server.

Copyright &copy; 2025-2026 United States Government as represented by the
National Aeronautics and Space Administration. No copyright is claimed in
the United States under Title 17, U.S.Code. All Other Rights Reserved.
"""

from datetime import datetime
from pathlib import Path
from typing import Annotated, List

from pydantic import Field

from fastmcp.exceptions import ToolError

from sscws.sscws import __version__ as sscws_version

import httpx

from app import __version__
from app.config import mcp, logger



MIN_ISO8601_FORMAT = '%Y%m%dT%H%M%SZ'
""" Minimal (no - or : separator characters) ISO 8601 format strftime format string. """

# Path to the bundled MCP App HTML file
MCP_APP_HTML_PATH = Path(__file__).parent.parent.parent.parent.parent.parent / \
    '4d-orbit-viewer' / 'dist-mcp' / 'mcp-app.html'

MCP_APP_HTML_URL = (
    'https://berniegsfc.github.io/sscmcp/dist-mcp/mcp-app.html'
#    'https://sscweb-dev.sci.gsfc.nasa.gov/',
#    '4dorbit/dist-mcp/mcp-app.html'
)
MCP_APP_RESOURCE_URI = 'ui://ssc/4d-orbit-viewer'


@mcp.resource(uri=MCP_APP_RESOURCE_URI)
async def get_4d_orbit_viewer_ui() -> str:
    """
    Returns the 4D Orbit Viewer MCP App HTML.

    Returns
    -------
    str
        The bundled HTML content for the 4D Orbit Viewer MCP App.
    """
    #if not MCP_APP_HTML_PATH.exists():
    #    logger.error('MCP App HTML not found at: %s', MCP_APP_HTML_PATH)
    #    raise ToolError('4D Orbit Viewer MCP App not built. ',
    #                    'Please run: cd ../4d-orbit-viewer && npm run build:mcp')
    #
    #logger.debug('Loading MCP App HTML from: %s', MCP_APP_HTML_PATH)
    #return MCP_APP_HTML_PATH.read_text()

    response = httpx.get(MCP_APP_HTML_URL)
    if response.status_code != 200:
        logger.error('MCP App HTML not found at: %s', MCP_APP_HTML_URL)
        raise ToolError('4D Orbit Viewer MCP App not built. ',
                        'Please run: cd ../4d-orbit-viewer && npm run build:mcp')

    logger.debug('Loading MCP App HTML from: %s', MCP_APP_HTML_URL)
    return response.text


@mcp.tool(
    name="show_4d_orbit_view",
    description="Displays an interactive 3D/4D orbit viewer showing spacecraft "
        "trajectories in space and time. This viewer allows you to explore "
        "the spacecraft's path, rotate the view, zoom, and animate the "
        "satellite's movement along its trajectory. The app renders inline "
        "within the conversation.",
    meta={
        "version": __version__,
        "author": "Bernie Harris",
        "ui": {
            "resourceUri": MCP_APP_RESOURCE_URI,
            "connectDomains": ["sscweb.gsfc.nasa.gov"],
        }
    }
)
async def show_4d_orbit_view(
    observatories: Annotated[
        List[str],
        Field(description="Observatories whose orbit is to be displayed. "
                  "The values must be from the set of id values returned "
                  "by get_observatories()",
              min_length=1)
    ],
    start: Annotated[datetime, "Start of the time interval to display"],
    end: Annotated[datetime, "End of the time interval to display"],
):
    """
    Displays an interactive 4D orbit viewer application showing the
    given spacecraft orbits during the given time range.

    Parameters
    ----------
    observatories
        List of observatories whose location is being requested. The
        values must be from the set of id values returned by
        get_observatories.
    start
        Start of the time interval to be displayed.
    end
        End of the time interval to be displayed.

    Returns
    -------
    dict
        Tool result with text content and structured content for the MCP App.

    Raises
    ------
    ToolError
        Raised when start is greater than end.
    """

    if start > end:
        raise ToolError('start time must be less than end time')

    start_str = start.strftime(MIN_ISO8601_FORMAT)
    end_str = end.strftime(MIN_ISO8601_FORMAT)

    # Fallback URL for non-MCP clients
    url = (
        f'https://sscweb.gsfc.nasa.gov/4dorbit/?'
        f'start={start_str}&stop={end_str}&'
        f'spacecraft={";".join(observatories)}'
    )

    logger.debug('show_4d_orbit_view: observatories=%s, start=%s, end=%s',
                 observatories, start_str, end_str)

    # Return both text content (fallback) and structured content (for MCP App)
    return {
        "content": [
            {
                "type": "text",
                "text": f"Displaying 4D orbit viewer for spacecraft: {', '.join(observatories)}\n"
                        f"Time range: {start_str} to {end_str}\n"
                        f"Fallback URL: {url}"
            }
        ],
        "structuredContent": {
            "spacecraft": ";".join(observatories),
            "start": start_str,
            "stop": end_str,
            "observatories": observatories
        }
    }


# Keep the old tool for backward compatibility (URL-only)
@mcp.tool(
    name="get_4d_orbit_view",
    description="Gets a URL of the interactive SSC 4D orbit viewer "
        "web application that displays the given spacecraft orbits "
        "during the given time range. Use show_4d_orbit_view for "
        "inline rendering.",
    meta={"version": __version__, "author": "Bernie Harris"}
)
async def get_4d_orbit_view(
    observatories: Annotated[
        List[str],
        Field(description="Observatories whose orbit is to be displayed. "
                  "The values must be from the set of id values returned "
                  "by get_observatories()",
              min_length=1)
    ],
    start: Annotated[datetime, "Start of the time interval to display"],
    end: Annotated[datetime, "End of the time interval to display"],
) -> str:
    """
    Gets a URL of a 4D orbit viewer web application that displays the
    given spacecraft orbits at the given time range.

    Parameters
    ----------
    observatories
        List of observatories whose location is being requested. The
        values must be from the set of id values returned by
        get_observatories.
    start
        Start of the time interval to be displayed.
    end
        End of the time interval to be displayed.

    Returns
    -------
    str
        URL of a 4D orbit viewer web application that displays the
        given spacecraft orbits at the given time range.

    Raises
    ------
    ToolError
        Raised when start is greater than end.
    """

    if start > end:
        raise ToolError('start time must be less than end time')

    start_str = start.strftime(MIN_ISO8601_FORMAT)
    end_str = end.strftime(MIN_ISO8601_FORMAT)

    url = (
        f'https://sscweb.gsfc.nasa.gov/4dorbit/?'
        f'start={start_str}&stop={end_str}&'
        f'spacecraft={";".join(observatories)}'
    )
    logger.debug('get_4d_orbit_view: returning %s', url)

    return url
