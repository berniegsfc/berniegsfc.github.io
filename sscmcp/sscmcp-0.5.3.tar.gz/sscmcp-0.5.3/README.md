
## Synopsis

NASA's [Satellite Situation Center](https://sscweb.gsfc.nasa.gov/)
(SSC) is a system to cast geocentric spacecraft location information 
into a framework of (empirical) geophysical regions and mappings of 
spacecraft locations along lines of the Earth's magnetic field.  
This application implements a [Model Context Protocol] server for
SSC.

## Example AI Prompts

- what satellites are available from nasa's ssc?

- what ground stations are available from nasa's ssc?

- over what time ranged does ssc have position information for iss?

- how can I view a 4D, interactive display of the international space station's orbit from 2026-01-01T00:00:00Z to 2026-01-02T00:00:00Z?

- display the GSE coordinates of the international space station from 2026-01-01T00:00:00Z to 2026-01-01T00:20:00Z.  Include the distance to the bow shock, the magnetic field strength, and the corresponding magnetoshere space region.

-  display the GSE coordinates of the international space station from 2026-01-01T00:00:00Z to 2026-01-01T00:20:00Z.  Include the distance to the bow
shock, the magnetic field strength, and the north and south magnetic field line traced footpoints in GEO latitude and longitude coordinates.

- display the radial traced conjunctions (time range and satellite GEO latitude, longitude) between iss and and a ground station named GSFC at latitude 39.99, longitude -76.84 during the time interval of 2018-07-12T00:00:00Z to 2018-07-15T23:59:59Z.

- display the magnetic field line traced conjunctions (in the same hemisphere as the satelite) of at least 2 of the 5 THEMIS spacecraft and one of the FSMI, WHIT, FSIM, or GAK THEMIS ground stations during the time from 2008-01-05T10:00:00Z to 2008-01-05T11:59:59Z.  Display the results as a table that includes the conjunction time range, satellite name and GEO latitude, longitude and ground station name.

- show me python code to get location information from ssc for the international space station.


## Motivation


## Dependencies

The only required dependencies are the following:

1. [fastmcp](https://pypi.org/project/fastmcp/)
2. [sscws](https://pypi.org/project/sscws/)
3. [pydantic](https://pypi.org/project/pydantic/)

The critical dependencies above will automatically be installed when this 
library is.

## Installation

To install this package

    $ pip install -U sscmcp


## API Reference

Refer to
[sscmcp application reference](https://berniegsfc.github.io/sscmcp/docs/py/index.html)


## Tests

The tests directory contains 
[unittest](https://docs.python.org/3/library/unittest.html)
tests.

## Contributors

Bernie Harris.  
[e-mail](mailto:NASA-SPDF-Support@nasa.onmicrosoft.com) for support.

## License

This code is licensed under the 
[NASA Open Source Agreement](https://berniegsfc.github.io/sscws/NASA_Open_Source_Agreement_1.3.txt) (NOSA).
