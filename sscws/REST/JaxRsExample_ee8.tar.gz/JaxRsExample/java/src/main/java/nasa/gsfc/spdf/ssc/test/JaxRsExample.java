/*
 * NOSA HEADER START
 *
 * The contents of this file are subject to the terms of the NASA Open 
 * Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may 
 * not use this file except in compliance with the Agreement.
 *
 * You can obtain a copy of the agreement at
 *   docs/NASA_Open_Source_Agreement_1.3.txt
 * or 
 *   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
 *
 * See the Agreement for the specific language governing permissions
 * and limitations under the Agreement.
 *
 * When distributing Covered Code, include this NOSA HEADER in each
 * file and include the Agreement file at 
 * docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the 
 * following below this NOSA HEADER, with the fields enclosed by 
 * brackets "[]" replaced with your own identifying information: 
 * Portions Copyright [yyyy] [name of copyright owner]
 *
 * NOSA HEADER END
 *
 * Copyright (c) 2022 United States Government as represented by 
 * the National Aeronautics and Space Administration. No copyright is 
 * claimed in the United States under Title 17, U.S.Code. All Other 
 * Rights Reserved.
 *
 */

package gov.nasa.gsfc.spdf.ssc.test;

import java.io.OutputStream;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;

import javax.ws.rs.WebApplicationException;

import javax.ws.rs.core.MediaType;
import static javax.ws.rs.core.Response.Status.SERVICE_UNAVAILABLE;
import static javax.ws.rs.core.Response.Status.TOO_MANY_REQUESTS;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;

import org.w3._1999.xhtml.Html;

import gov.nasa.gsfc.sscweb.schema.*;



/**
 * This class provides an example JAX-RS client which demonstrates
 * calling NASA's Satellite Situation Center
 * <a href="https://sscweb.gsfc.nasa.gov/WebServices/REST">(SSC) RESTful 
 * Web Services</a>.
 *
 * @author B. Harris
 */
public class JaxRsExample {

    /**
     * JAX-RS client.
     */
    private Client client = ClientBuilder.newClient();

    /**
     * HTTP user-agent value.
     */
    private static final String USER_AGENT = "JaxRsExample";

    /**
     * JAXB context for SSC XML data.
     */
    private JAXBContext sscJaxbContext =
        JAXBContext.newInstance("gov.nasa.gsfc.sscweb.schema");

    /**
     * JAXB context for XHTML data.
     */
    private JAXBContext xhtmlJaxbContext =
        JAXBContext.newInstance("org.w3._1999.xhtml");

    /**
     * Factory that creates new <code>javax.xml.datatype</code> 
     * Objects that map XML to/from Java Objects.
     */
    private DatatypeFactory datatypeFactory = null;

    /**
     * Factory that creates new <code>gov.nasa.gsfc.sscweb.schema</code>
     * objects.
     */
    private ObjectFactory sscFactory = new ObjectFactory();

    /**
     * Endpoint address of SSC REST web service.
     */
    private String endpoint = "https://sscweb.gsfc.nasa.gov/WS/sscr/2";


    public JaxRsExample(String endpoint)
        throws JAXBException {

        this.endpoint = endpoint;

        try {

            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (DatatypeConfigurationException e) {

            System.err.println(
                "DatatypeFactory.newInstance failed with exception: " +
                e.getMessage());
        }

    }


    public ObjectFactory getObjectFactory() {

        return sscFactory;
    }


    public List<ObservatoryDescription> getObservatories()
        throws SocketException {

        String url = endpoint + "/observatories/";

        WebTarget ssc = client.target(url);
        Invocation.Builder request = 
            ssc.request(MediaType.APPLICATION_XML);
        Invocation invocation = 
            request.header("User-Agent", USER_AGENT).buildGet();

        ObservatoryResponse response =
            invocation.invoke(ObservatoryResponse.class);

        return response.getObservatory();
    }


    public List<GroundStation> getGroundStations() {

        String url = endpoint + "/groundStations/";

        WebTarget ssc = client.target(url);
        Invocation.Builder request = 
            ssc.request(MediaType.APPLICATION_XML);
        Invocation invocation = 
            request.header("User-Agent", USER_AGENT).buildGet();

        GroundStationResponse response =
            invocation.invoke(GroundStationResponse.class);

        return response.getGroundStation();
    }


    public List<SatelliteData> getData(
        DataRequest dataRequest) 
        throws Exception {

/*
try {

    marshal(System.out, dataRequest);
}
catch (JAXBException e) {

    System.err.println("getConjunctions: JAXBException: " +
        e.getMessage());

    return null;
}
*/

        String url = endpoint + "/locations/";

        WebTarget ssc = client.target(url);

        Entity<DataRequest> dataRequestEntity =
            Entity.entity(dataRequest, MediaType.APPLICATION_XML);

        Invocation.Builder request = 
            ssc.request(MediaType.APPLICATION_XML);

        Invocation invocation = 
            request.header("User-Agent", USER_AGENT).
                buildPost(dataRequestEntity);

        Response dataResponse = invocation.invoke(Response.class);

        DataResult dataResult = (DataResult)dataResponse.getResult();

        if (dataResult.getStatusCode() != 
            ResultStatusCode.SUCCESS) {

            System.out.println("getData: dataResult.getStatusCode() = " +
                dataResult.getStatusCode());
        }

        return dataResult.getData();
    }

    public List<FileDescription> getFile(
        DataRequest dataRequest) 
        throws Exception {

        String url = endpoint + "/locations/";

        WebTarget ssc = client.target(url);

        Entity<DataRequest> dataRequestEntity =
            Entity.entity(dataRequest, MediaType.APPLICATION_XML);

        Invocation.Builder request = 
            ssc.request(MediaType.APPLICATION_XML);

        Invocation invocation = 
            request.header("User-Agent", USER_AGENT).
                buildPost(dataRequestEntity);

        Response dataResponse = invocation.invoke(Response.class);

        FileResult dataResult = (FileResult)dataResponse.getResult();

        if (dataResult.getStatusCode() != 
            ResultStatusCode.SUCCESS) {

            System.out.println("getData: dataResult.getStatusCode() = " +
                dataResult.getStatusCode());
        }

        return dataResult.getFiles();
    }


    private void marshal(OutputStream out, java.lang.Object value)
        throws JAXBException {

        Marshaller marshaller = null;

        if (value instanceof ObservatoryResponse ||
            value instanceof GroundStationResponse ||
            value instanceof DataResult ||
            value instanceof DataRequest) {

            marshaller = sscJaxbContext.createMarshaller();
        }
        else if (value instanceof org.w3._1999.xhtml.Html) {

            marshaller = xhtmlJaxbContext.createMarshaller();
        }
        else {

            System.err.println("Don't know how to marshall " +
                value.getClass().getName());
        }
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                               Boolean.TRUE);

        marshaller.marshal(value, out);
    }

    private OutputOptions getTestOutputOptions() {

        LocationFilter locationFilter = 
            getObjectFactory().createLocationFilter();
                                       // a test LocationFilter to use
                                       //  with all
        locationFilter.setMinimum(true);
        locationFilter.setMaximum(true);
        locationFilter.setLowerLimit(-100.0);
        locationFilter.setUpperLimit(100.0);

        List<FilteredCoordinateOptions> options =
            new ArrayList<FilteredCoordinateOptions>();
                                       // some test coordinate options

        for (CoordinateComponent component :
             CoordinateComponent.values()) {

            FilteredCoordinateOptions option =
                new FilteredCoordinateOptions();

            option.setCoordinateSystem(CoordinateSystem.GSE);
            option.setComponent(component);
            option.setFilter(null);
//            option.setFilter(locationFilter);

            options.add(option);
        }

        RegionOptions regionOptions = 
            getObjectFactory().createRegionOptions();
                                       // region listing options
        regionOptions.setSpacecraft(true);
        regionOptions.setRadialTracedFootpoint(true);
        regionOptions.setNorthBTracedFootpoint(true);
        regionOptions.setSouthBTracedFootpoint(false);

        ValueOptions valueOptions = 
            getObjectFactory().createValueOptions();
                                       // value listing options
        valueOptions.setBFieldStrength(true);
        valueOptions.setDipoleInvLat(true);
        valueOptions.setDipoleLValue(true);
        valueOptions.setRadialDistance(true);

        DistanceFromOptions distanceFromOptions =
            getObjectFactory().createDistanceFromOptions();
                                       // distance from options
        distanceFromOptions.setBGseXYZ(true);
        distanceFromOptions.setBowShock(true);
        distanceFromOptions.setMPause(true);
        distanceFromOptions.setNeutralSheet(true);

        BFieldTraceOptions geoNorthBFieldTrace =
            getObjectFactory().createBFieldTraceOptions();
                                       // GEO north B field trace
                                       // options
        geoNorthBFieldTrace.setCoordinateSystem(CoordinateSystem.GEO);
        geoNorthBFieldTrace.setFieldLineLength(true);
        geoNorthBFieldTrace.setFootpointLatitude(true);
        geoNorthBFieldTrace.setFootpointLongitude(true);
        geoNorthBFieldTrace.setHemisphere(Hemisphere.NORTH);

        BFieldTraceOptions geoSouthBFieldTrace =
            getObjectFactory().createBFieldTraceOptions();
                                       // GEO south B field trace
                                       // options
        geoSouthBFieldTrace.setCoordinateSystem(CoordinateSystem.GEO);
        geoSouthBFieldTrace.setFieldLineLength(true);
        geoSouthBFieldTrace.setFootpointLatitude(true);
        geoSouthBFieldTrace.setFootpointLongitude(true);
        geoSouthBFieldTrace.setHemisphere(Hemisphere.SOUTH);

        BFieldTraceOptions gmNorthBFieldTrace =
            getObjectFactory().createBFieldTraceOptions();
                                       // GM north B field trace options
        gmNorthBFieldTrace.setCoordinateSystem(CoordinateSystem.GM);
        gmNorthBFieldTrace.setFieldLineLength(true);
        gmNorthBFieldTrace.setFootpointLatitude(true);
        gmNorthBFieldTrace.setFootpointLongitude(true);
        gmNorthBFieldTrace.setHemisphere(Hemisphere.NORTH);

        BFieldTraceOptions gmSouthBFieldTrace =
            getObjectFactory().createBFieldTraceOptions();
                                       // GM south B field trace options
        gmSouthBFieldTrace.setCoordinateSystem(CoordinateSystem.GM);
        gmSouthBFieldTrace.setFieldLineLength(true);
        gmSouthBFieldTrace.setFootpointLatitude(true);
        gmSouthBFieldTrace.setFootpointLongitude(true);
        gmSouthBFieldTrace.setHemisphere(Hemisphere.SOUTH);

        OutputOptions outputOptions = 
            getObjectFactory().createOutputOptions();

        outputOptions.setAllLocationFilters(true);
        outputOptions.getCoordinateOptions().addAll(options);
        outputOptions.setRegionOptions(regionOptions);
        outputOptions.setValueOptions(valueOptions);
        outputOptions.setDistanceFromOptions(distanceFromOptions);
        outputOptions.setMinMaxPoints(2);
        outputOptions.getBFieldTraceOptions().add(geoNorthBFieldTrace);
        outputOptions.getBFieldTraceOptions().add(geoSouthBFieldTrace);
        outputOptions.getBFieldTraceOptions().add(gmNorthBFieldTrace);
        outputOptions.getBFieldTraceOptions().add(gmSouthBFieldTrace);

        return outputOptions;
    }

    enum ResultType {
        DATA,
        CDF,
        LISTING
    }

    private DataRequest getTestDataRequest(
        ResultType resultType) {

        XMLGregorianCalendar start = 
            datatypeFactory.newXMLGregorianCalendar(
                2008, 1, 2, 11, 0, 0, 0, 0);
        XMLGregorianCalendar end = 
            datatypeFactory.newXMLGregorianCalendar(
                2008, 1, 2, 11, 59, 59, 0, 0);

        TimeInterval timeInterval = 
            getObjectFactory().createTimeInterval();
        timeInterval.setStart(start);
        timeInterval.setEnd(end);

        SatelliteSpecification fastSat = 
            getObjectFactory().createSatelliteSpecification();
        fastSat.setId("fast");
        fastSat.setResolutionFactor(2);

        SatelliteSpecification moonSat = 
            getObjectFactory().createSatelliteSpecification();
        moonSat.setId("moon");
        moonSat.setResolutionFactor(2);

        SpaceRegionsFilterOptions spaceRegionsFilter =
            getObjectFactory().createSpaceRegionsFilterOptions();
                                       // space regions filter options
        spaceRegionsFilter.setDaysideMagnetosheath(true);
        spaceRegionsFilter.setDaysideMagnetosphere(true);
        spaceRegionsFilter.setDaysidePlasmasphere(true);
        spaceRegionsFilter.setHighLatitudeBoundaryLayer(true);
        spaceRegionsFilter.setInterplanetaryMedium(true);
        spaceRegionsFilter.setLowLatitudeBoundaryLayer(true);
        spaceRegionsFilter.setNightsideMagnetosheath(true);
        spaceRegionsFilter.setNightsideMagnetosphere(true);
        spaceRegionsFilter.setNightsidePlasmasphere(true);
        spaceRegionsFilter.setPlasmaSheet(true);
        spaceRegionsFilter.setTailLobe(true);

        HemisphereOptions hemisphereOptions =
            new HemisphereOptions();
                                       // hemisphere listing options
                                       //  requesting both the north and
                                       //  south hemisphere
        hemisphereOptions.setNorth(true);
        hemisphereOptions.setSouth(true);

        MappedRegionFilterOptions radialTraceRegionsFilter =
            new MappedRegionFilterOptions();
                                       // radial traced regions filter
        radialTraceRegionsFilter.setCusp(hemisphereOptions);
        radialTraceRegionsFilter.setCleft(hemisphereOptions);
        radialTraceRegionsFilter.setAuroralOval(hemisphereOptions);
        radialTraceRegionsFilter.setPolarCap(hemisphereOptions);
        radialTraceRegionsFilter.setMidLatitude(hemisphereOptions);
        radialTraceRegionsFilter.setLowLatitude(true);

        MappedRegionFilterOptions magneticTraceRegionsFilter =
            radialTraceRegionsFilter;
                                       // magnetic traced regions filter

        RegionFilterOptions regionFilters =
            new RegionFilterOptions();
                                       // region filter
        regionFilters.setSpaceRegions(spaceRegionsFilter);
        regionFilters.setRadialTraceRegions(radialTraceRegionsFilter);
        regionFilters.setMagneticTraceRegions(
            magneticTraceRegionsFilter);

        LocationFilter locationFilter = new LocationFilter();
                                       // a location filter
        locationFilter.setMinimum(true);
        locationFilter.setMaximum(true);
        locationFilter.setLowerLimit(-500.0);
        locationFilter.setUpperLimit(500.0);

        LocationFilterOptions locationFilterOptions =
            new LocationFilterOptions();
                                       // location filter options
        locationFilterOptions.setAllFilters(true);
        locationFilterOptions.setDistanceFromCenterOfEarth(
            locationFilter);
        locationFilterOptions.setMagneticFieldStrength(locationFilter);
        locationFilterOptions.setDistanceFromNeutralSheet(
            locationFilter);
        locationFilterOptions.setDistanceFromBowShock(locationFilter);
        locationFilterOptions.setDistanceFromMagnetopause(
            locationFilter);
        locationFilterOptions.setDipoleLValue(locationFilter);
        locationFilterOptions.setDipoleInvariantLatitude(
            locationFilter);

        BFieldModel bFieldModel =
            getObjectFactory().createBFieldModel();
        bFieldModel.setTraceStopAltitude(100);
        bFieldModel.setInternalBFieldModel(
            InternalBFieldModel.IGRF);

        Tsyganenko89CBFieldModel t89c =
            getObjectFactory().createTsyganenko89CBFieldModel();
        t89c.setKeyParameterValues(Tsyganenko89CKp.KP_3_3_3);

        bFieldModel.setExternalBFieldModel(t89c);

        DataRequest dataRequest = getObjectFactory().createDataRequest();
                                        // test data request
        dataRequest.setTimeInterval(timeInterval);
        dataRequest.setBFieldModel(bFieldModel);
        dataRequest.getSatellites().add(fastSat);
        dataRequest.getSatellites().add(moonSat);

        dataRequest.setOutputOptions(getTestOutputOptions());

//        dataRequest.setRegionFilterOptions(regionFilters);
//        dataRequest.setLocationFilterOptions(locationFilterOptions);
//        dataRequest.setBFieldModelOptions(bFieldModelOptions);

        if (resultType != ResultType.DATA) {

            dataRequest.setFormatOptions(getTestFormatOptions(resultType));
        }

        return dataRequest;
    }

    private FormatOptions getTestFormatOptions(
        ResultType resultType) {

        FormatOptions formatOptions = 
            getObjectFactory().createFormatOptions();

        formatOptions.setDateFormat(DateFormat.YYYY_DDD);
        formatOptions.setTimeFormat(TimeFormat.HH_MM_SS);
        formatOptions.setDistanceFormat(DistanceFormat.RE);
        formatOptions.setDistanceDigits(2);
        formatOptions.setDegreeFormat(DegreeFormat.DECIMAL);
        formatOptions.setDegreeDigits(2);
        formatOptions.setLatLonFormat(LatLonFormat.LAT_90_LON_360);
        formatOptions.setLinesPerPage(55);

        formatOptions.setCdf(resultType == ResultType.CDF ? true : false);

        return formatOptions;
    }


    public void execute() 
        throws Exception {

        List<ObservatoryDescription> observatories = getObservatories();

        System.out.println("Observatories:");
        for (ObservatoryDescription observatory : observatories) {

            System.out.println("  " + observatory.getName() + "  " +
                observatory.getStartTime() + "  " +
                observatory.getEndTime());
        }

        List<GroundStation> groundStations = getGroundStations();

        System.out.println();
        System.out.println("Ground Stations:");
        for (GroundStation groundStation : groundStations) {

            SurfaceGeographicCoordinates 
                coordinates = groundStation.getLocation();
            System.out.println("  " + groundStation.getId() + "  " +
                coordinates.getLatitude() + "  " + 
                coordinates.getLongitude());
        }

        DataRequest testRequest = getTestDataRequest(ResultType.DATA);

        List<SatelliteData> satData = getData(testRequest);

        for (SatelliteData datum : satData) {

            print(datum);
        }

        List<FileDescription> cdfData = 
            getFile(getTestDataRequest(ResultType.CDF));

        System.out.println();
        System.out.println("Result files:");
        for (FileDescription file : cdfData) {

            System.out.println("  " + file.getName());
        }
    }

    private static void print(SatelliteData data) {

        System.out.println("  " + data.getId());

        List<XMLGregorianCalendar> time = data.getTime();
        List<CoordinateData> coords = data.getCoordinates();
        List<Double> radialLength = data.getRadialLength();
        List<Double> magneticStrength = data.getMagneticStrength();
        List<Double> ns = data.getNeutralSheetDistance();
        List<Double> bs = data.getBowShockDistance();
        List<Double> mp = data.getMagnetoPauseDistance();
        List<Double> lv = data.getDipoleLValue();
        List<Float> il = data.getDipoleInvariantLatitude();
        List<SpaceRegion> sr = data.getSpacecraftRegion();
        List<FootpointRegion> rtr =
            data.getRadialTracedFootpointRegions();
        List<FootpointRegion> nbtr = 
            data.getNorthBTracedFootpointRegions();
        List<FootpointRegion> sbtr = 
            data.getSouthBTracedFootpointRegions();
        List<Double> bGseX = data.getBGseX();
        List<Double> bGseY = data.getBGseY();
        List<Double> bGseZ = data.getBGseZ();

        printHeading(coords, radialLength, magneticStrength, ns, bs, mp,
                     lv, il, sr, rtr, nbtr, sbtr, bGseX, bGseY, bGseZ);

        print(time, coords, radialLength, magneticStrength, ns, bs, mp,
              lv, il, sr, rtr, nbtr, sbtr, bGseX, bGseY, bGseZ,
              5);

    }


    private static void printHeading(List<CoordinateData> coords,
        List<Double> radialLength, List<Double> magneticStrength,
        List<Double> ns, List<Double> bs, List<Double> mp,
        List<Double> lv, List<Float> il, List<SpaceRegion> sr,
        List<FootpointRegion> rtr, List<FootpointRegion> nbtr,
        List<FootpointRegion> sbtr,
        List<Double> bGseX, List<Double> bGseY, List<Double> bGseZ) {

        StringBuffer hdr1 = new StringBuffer();
        StringBuffer hdr2 = new StringBuffer();

        hdr1.append("  Time                 ");
        hdr2.append("                       ");

        for (CoordinateData point : coords) {

            List<Double> x = point.getX();
            List<Double> y = point.getY();
            List<Double> z = point.getZ();
            List<Float> lat = point.getLatitude();
            List<Float> lon = point.getLongitude();
            List<Double> lt = point.getLocalTime();

            if (x != null && x.size() > 0) {

                hdr1.append("         ");
                hdr2.append("      X  ");
            }

            if (y != null && y.size() > 0) {

                hdr1.append("            ");
                hdr2.append("         Y  ");
            }

            hdr1.append(point.getCoordinateSystem() + "         ");

            if (z != null && z.size() > 0) {

                hdr2.append("         Z  ");
            }

            if (lat != null && lat.size() > 0) {

                hdr1.append("           ");
                hdr2.append("      Lat  ");
            }

            if (lon != null && lon.size() > 0) {

                hdr1.append("           ");
                hdr2.append("      Lon  ");
            }

            if (lt != null && lt.size() > 0) {

                hdr1.append("        Local  ");
                hdr2.append("         Time  ");
            }
        } // endfor each coords

        if (radialLength != null && radialLength.size() > 0) {

            hdr1.append("    Radial ");
            hdr2.append("    Length ");
        }

        if (magneticStrength != null && magneticStrength.size() > 0) {

            hdr1.append("    Magnetic ");
            hdr2.append("    Strength ");
        }

        if (ns != null && ns.size() > 0) {

            hdr1.append("    Neutral ");
            hdr2.append("    Sheet   ");
        }

        if (bs != null && bs.size() > 0) {

            hdr1.append("    Bow     ");
            hdr2.append("    Shock   ");
        }

        if (mp != null && mp.size() > 0) {

            hdr1.append("    Magneto ");
            hdr2.append("    Pause   ");
        }

        if (lv != null && lv.size() > 0) {

            hdr1.append("    Dipole  ");
            hdr2.append("    L Value ");
        }

        if (il != null && il.size() > 0) {

            hdr1.append("    Dipole  ");
            hdr2.append("    InvLat  ");
        }

        if (sr != null && sr.size() > 0) {

            hdr1.append("  Spacecraft ");
            hdr2.append("  Region     ");
        }

        if (rtr != null && rtr.size() > 0) {

            hdr1.append("  Radial Trc ");
            hdr2.append("  Region     ");
        }

        if (nbtr != null && nbtr.size() > 0) {

            hdr1.append("  N BTraced ");
            hdr2.append("  Region    ");
        }

        if (sbtr != null && sbtr.size() > 0) {

            hdr1.append("  S BTraced ");
            hdr2.append("  Region    ");
        }

        if (bGseX != null && bGseX.size() > 0) {

            hdr1.append("    GSE    ");
            hdr2.append("    X      ");
        }

        if (bGseY != null && bGseY.size() > 0) {

            hdr1.append("  Magnetic ");
            hdr2.append("    Y      ");
        }

        if (bGseZ != null && bGseZ.size() > 0) {

            hdr1.append("  Vectors ");
            hdr2.append("    Z     ");
        }


        System.out.println(hdr1);
        System.out.println(hdr2);
    }


    private static void print(List<XMLGregorianCalendar> time,
        List<CoordinateData> coords, List<Double> radialLength,
        List<Double> magneticStrength, List<Double> ns,
        List<Double> bs, List<Double> mp, List<Double> lv,
        List<Float> il, List<SpaceRegion> sr,
        List<FootpointRegion> rtr, List<FootpointRegion> nbtr,
        List<FootpointRegion> sbtr, List<Double> bGseX,
        List<Double> bGseY, List<Double> bGseZ, int numValues) {

        if (numValues < 0) {

            numValues = time.size();
        }

        for (int i = 0; i < time.size() && i < numValues; i++) {

            System.out.println("  " + time.get(i));

            for (int j = 0; j < coords.size(); j++) {

                List<Double> x = coords.get(j).getX();
                List<Double> y = coords.get(j).getY();
                List<Double> z = coords.get(j).getZ();
                List<Float> lat = coords.get(j).getLatitude();
                List<Float> lon = coords.get(j).getLongitude();
                List<Double> lt = coords.get(j).getLocalTime();

                if (x != null && i < x.size()) {

                    System.out.printf("  %10.2f", x.get(i));
                }

                if (y != null && i < y.size()) {

                    System.out.printf("  %10.2f", y.get(i));
                }

                if (z != null && i < z.size()) {

                    System.out.printf("  %10.2f", z.get(i));
                }

                if (lat != null && i < lat.size()) {

                    System.out.printf("  %10.2f", lat.get(i));
                }

                if (lon != null && i < lon.size()) {

                    System.out.printf("  %10.2f", lon.get(i));
                }

                if (lt != null && i < lt.size()) {

                    System.out.printf("  %10.2f", lt.get(i));
                }
            } // endfor each coords

            if (radialLength != null && i < radialLength.size()) {

                System.out.printf("  %10.2f" , radialLength.get(i));
            }

            if (magneticStrength != null &&
                i < magneticStrength.size()) {

                if (magneticStrength.get(i) == -1.0E31D) {

                    System.out.print("      NA    ");
                }
                else {

                    System.out.printf("  %10.2f" ,
                        magneticStrength.get(i));
                }
            }

            if (ns != null && i < ns.size()) {

                if (ns.get(i) == -1.0E31D) {

                    System.out.print("      NA    ");
                }
                else {

                    System.out.printf("  %10.2f" , ns.get(i));
                }
            }

            if (bs != null && i < bs.size()) {

                System.out.printf("  %10.2f" , bs.get(i));
            }

            if (mp != null && i < mp.size()) {

                System.out.printf("  %10.2f" , mp.get(i));
            }

            if (lv != null && i < lv.size()) {

                System.out.printf("  %10.2f" , lv.get(i));
            }

            if (il != null && i < il.size()) {

                System.out.printf("  %10.2f" , il.get(i));
            }

            if (sr != null && i < sr.size()) {

                System.out.printf("  %10s", getSpaceRegion(sr.get(i)));
            }

            if (rtr != null && i < rtr.size()) {

                System.out.printf("  %10s" ,
                    getTracedRegion(rtr.get(i)));
            }

            if (nbtr != null && i < nbtr.size()) {

                System.out.printf("  %10s" ,
                    getTracedRegion(nbtr.get(i)));
            }

            if (sbtr != null && i < sbtr.size()) {

                System.out.printf("  %10s" ,
                    getTracedRegion(sbtr.get(i)));
            }

            if (bGseX != null && i < bGseX.size()) {

                if (bGseX.get(i) == -1.0E31D) {

                    System.out.print("      NA    ");
                }
                else {

                    System.out.printf("  %10.2f" , bGseX.get(i));
                }
            }

            if (bGseY != null && i < bGseY.size()) {

                if (bGseY.get(i) == -1.0E31D) {

                    System.out.print("      NA    ");
                }
                else {

                    System.out.printf("  %10.2f" , bGseY.get(i));
                }
            }

            if (bGseZ != null && i < bGseZ.size()) {

                if (bGseZ.get(i) == -1.0E31D) {

                    System.out.print("      NA    ");
                }
                else {

                    System.out.printf("  %10.2f" , bGseZ.get(i));
                }
            }

            System.out.println();
        } // endfor each time value
    }

    private static String getSpaceRegion(SpaceRegion value) {

        switch (value) {

        case INTERPLANETARY_MEDIUM:

            return "Intpl Med";

        case DAYSIDE_MAGNETOSHEATH:

            return "D Msheath";

        case NIGHTSIDE_MAGNETOSHEATH:

            return "N Msheath";

        case DAYSIDE_MAGNETOSPHERE:

            return "D Msphere";

        case NIGHTSIDE_MAGNETOSPHERE:

            return "N Msphere";

        case PLASMA_SHEET:

            return "Plasma Sh";

        case TAIL_LOBE:

            return "Tail Lobe";

        case HIGH_LATITUDE_BOUNDARY_LAYER:

            return "HLB Layer";

        case LOW_LATITUDE_BOUNDARY_LAYER:

            return "LLB Layer";

        case DAYSIDE_PLASMASPHERE:

            return "D Psphere";

        case NIGHTSIDE_PLASMASPHERE:

            return "N Psphere";

        default:

            return value.toString();
        }
    }

    private static String getTracedRegion(FootpointRegion value) {

        switch (value) {

        case NORTH_CUSP:

            return "N Cusp   ";

        case SOUTH_CUSP:

            return "S Cusp   ";

        case NORTH_CLEFT:

            return "N Cleft  ";

        case SOUTH_CLEFT:

            return "S Cleft  ";

        case NORTH_AURORAL_OVAL:

            return "N Oval   ";

        case SOUTH_AURORAL_OVAL:

            return "S Oval   ";

        case NORTH_POLAR_CAP:

            return "N PolrCap";

        case SOUTH_POLAR_CAP:

            return "S PolrCap";

        case NORTH_MID_LATITUDE:

            return "N Mid-Lat";

        case SOUTH_MID_LATITUDE:

            return "S Mid-Lat";

        case LOW_LATITUDE:

            return "Low Lat  ";

        default:

            return "  None   ";
        }
    }


    public static void main(String[] args) 
        throws Exception {

        String endpoint = "https://sscweb.gsfc.nasa.gov/WS/sscr/2";

        if (args.length == 1) {

            endpoint = args[0];
        }

        JaxRsExample example = new JaxRsExample(endpoint);

        try {

            example.execute();
        }
        catch (WebApplicationException e) {

            javax.ws.rs.core.Response resp = e.getResponse();
            javax.ws.rs.core.Response.Status status = 
                resp.getStatusInfo().toEnum();
            String retryAfter = null;
            if (status == TOO_MANY_REQUESTS ||
                status == SERVICE_UNAVAILABLE) {

                retryAfter = resp.getHeaderString("Retry-After");
            }
            org.w3._1999.xhtml.Html msg = 
                resp.readEntity(org.w3._1999.xhtml.Html.class);

            System.out.println("WebApplicationException: " + 
                e.getMessage());
            example.marshal(System.out, msg);

            e.printStackTrace();
        }
    }

}
