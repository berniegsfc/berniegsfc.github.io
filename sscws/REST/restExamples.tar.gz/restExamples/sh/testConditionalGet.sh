#!/bin/bash

sscUrl="https://sscweb.gsfc.nasa.gov/WS/sscr/2"
#sscUrl="https://sscweb-dev.sci.gsfc.nasa.gov/WS/sscr/2"
sscObsUrl="${sscUrl}/observatories"

caCert="-k"
#caCert="--cacert ca-bundle.crt"

resultFile=`mktemp -t sscObsXXXXXX`

printf "Getting observatories from ${sscObsUrl}\n\n"
curl -s -i ${caCert} -o "${resultFile}" "${sscObsUrl}"
head -8 "${resultFile}"
eTag="`awk '/ETag/{print substr($2, 1, length($2) - 1)}' ${resultFile}`"

printf "Performing a conditional GET with ETag = %s\n\n" "${eTag}"
 
curl -s -i ${caCert} -H "If-None-Match: ${eTag}" "${sscObsUrl}" | head -7


rm -f "${resultFile}"

exit 0


