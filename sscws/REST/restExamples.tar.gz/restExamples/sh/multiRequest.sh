#!/bin/bash
#
# For testing concurrency limits.  Make multiple concurrent requests.
#

for i in 1 2 3 4 5 6
do
    curl -s -H "Content-Type: application/xml" --data-ascii @conjunctions/requests/barrel1a_rbsp.xml https://sscweb.gsfc.nasa.gov/WS/sscr/2/conjunctions | xmllint --format - &
#    curl -s -H "Content-Type: application/xml" --data-ascii @locations/requests/themis2.xml https://sscweb-dev.sci.gsfc.nasa.gov/WS/sscr/2/locations | xmllint --format - &
#    curl -s -H "Content-Type: application/xml" --data-ascii @locations/requests/geotail1.xml https://sscweb-dev.sci.gsfc.nasa.gov/WS/sscr/2/locations | xmllint --format - &
#    curl -s -H "Content-Type: application/xml" --data-ascii @graphs/requests/themisTimeSeriesGraph.xml https://sscweb-dev.sci.gsfc.nasa.gov/WS/sscr/2/graphs | xmllint --format - &
#    sleep 1
done
exit 0
